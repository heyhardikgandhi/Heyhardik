# THE GOLDEN 25 — Deployment

## Structure
index.html (site: CSS+JS inline) · netlify.toml · package.json
netlify/functions/ rsvp.mjs, wish.mjs, wall.mjs, admin.mjs, _lib.mjs

## Backend
Netlify Functions + Netlify Blobs (built in, free tier, no external account, no keys in frontend).
Stored: RSVPs (name, attendance, guests, drinks, message, timestamp) and wall messages.

## Deploy
1. Push this folder to GitHub, then Netlify > Add new site > Import from Git (build command empty, publish dir `.`).
   (Plain drag-and-drop does NOT deploy functions; use Git or `npx netlify deploy --prod`.)
2. Site settings > Environment variables: add `ADMIN_KEY` = a long secret.
3. Redeploy.

## See responses
`https://YOUR-SITE/api/admin?key=ADMIN_KEY` (JSON + headcount) or add `&format=csv` for a spreadsheet.

## Checklist
- [ ] Unlock button -> confetti, gate fades
- [ ] Countdown ticks (target 14 Nov 2026, 8 PM IST)
- [ ] Maps button opens Noida venue
- [ ] Drinks toggle (multi-select), shown in RSVP
- [ ] RSVP yes -> "YOU'RE ON THE LIST!"; no -> thank-you; same name again -> blocked
- [ ] RSVP appears in /api/admin; message appears on wall
- [ ] Wall post appears instantly; refreshes every 30s
- [ ] WhatsApp button opens chat with prefilled text
- [ ] Music toggle starts only on tap
- [ ] Hamburger menu + back-to-top on phone
