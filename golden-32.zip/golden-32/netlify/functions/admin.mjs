import { getStore } from "@netlify/blobs";
import { j } from "./_lib.mjs";
const all = async n => { const s = getStore(n), { blobs } = await s.list(); return (await Promise.all(blobs.map(b => s.get(b.key, { type: "json" })))).filter(Boolean); };
export default async (req) => {
  const u = new URL(req.url), k = process.env.ADMIN_KEY;
  if (!k || u.searchParams.get("key") !== k) return j({ error: "Unauthorized" }, 401);
  const rsvps = (await all("rsvps")).sort((a, b) => a.submittedAt < b.submittedAt ? 1 : -1);
  if (u.searchParams.get("format") === "csv") {
    const q = v => `"${String(v).replace(/"/g, '""')}"`;
    const rows = [["Name", "Attending", "Guests", "Drinks", "Message", "Submitted"].join(",")].concat(rsvps.map(r => [r.name, r.attending, r.guests, r.drinks.join("/"), r.message, r.submittedAt].map(q).join(",")));
    return new Response(rows.join("\n"), { headers: { "Content-Type": "text/csv", "Content-Disposition": "attachment; filename=rsvps.csv" } });
  }
  const yes = rsvps.filter(r => r.attending === "yes");
  return j({ summary: { responses: rsvps.length, yes: yes.length, no: rsvps.length - yes.length, headcount: yes.reduce((a, r) => a + 1 + r.guests, 0) }, rsvps, wishes: await all("wishes") });
};
