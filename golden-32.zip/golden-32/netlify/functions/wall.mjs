import { getStore } from "@netlify/blobs";
import { j } from "./_lib.mjs";
export default async () => {
  const s = getStore("wishes"), { blobs } = await s.list();
  const keys = blobs.map(b => b.key).sort().reverse().slice(0, 100);
  const items = (await Promise.all(keys.map(k => s.get(k, { type: "json" })))).filter(Boolean);
  return j({ items });
};
