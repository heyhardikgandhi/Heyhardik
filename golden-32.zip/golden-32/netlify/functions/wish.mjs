import { getStore } from "@netlify/blobs";
import { j, slug, hash, clean } from "./_lib.mjs";
export async function addWish(name, message, kind) {
  const dd = getStore("wish-dedupe"), id = slug(name) + "-" + hash(message.toLowerCase());
  if (await dd.get(id)) return false;
  await dd.set(id, "1");
  await getStore("wishes").setJSON(`${String(Date.now()).padStart(14, "0")}-${id}`, { name, message, kind, ts: new Date().toISOString() });
  return true;
}
export default async (req) => {
  if (req.method !== "POST") return j({ error: "Method not allowed" }, 405);
  let b; try { b = await req.json(); } catch { return j({ error: "Bad request" }, 400); }
  if (b.website) return j({ ok: true });
  const name = clean(b.name, 60), message = clean(b.message, 500), kind = b.kind === "roast" ? "roast" : "wish";
  if (name.length < 2 || message.length < 2) return j({ error: "Add your name and a message." }, 400);
  return (await addWish(name, message, kind)) ? j({ ok: true }) : j({ error: "duplicate" }, 409);
};
