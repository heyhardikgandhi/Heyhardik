import { getStore } from "@netlify/blobs";
import { j, slug, clean } from "./_lib.mjs";
import { addWish } from "./wish.mjs";
const DRINKS = ["Whiskey", "Gin", "Vodka", "Beer"];
export default async (req) => {
  if (req.method !== "POST") return j({ error: "Method not allowed" }, 405);
  let b; try { b = await req.json(); } catch { return j({ error: "Bad request" }, 400); }
  if (b.website) return j({ ok: true }); // honeypot
  const name = clean(b.name, 60), message = clean(b.message, 500);
  const attending = b.attending === "yes" ? "yes" : b.attending === "no" ? "no" : null;
  const guests = Math.max(0, Math.min(10, parseInt(b.guests) || 0));
  const drinks = (Array.isArray(b.drinks) ? b.drinks : []).filter(d => DRINKS.includes(d));
  if (name.length < 2 || !slug(name)) return j({ error: "Please enter your name." }, 400);
  if (!attending) return j({ error: "Tell me if you're coming!" }, 400);
  const store = getStore("rsvps"), key = slug(name);
  if (await store.get(key)) return j({ error: "duplicate" }, 409);
  await store.setJSON(key, { name, attending, guests: attending === "yes" ? guests : 0, drinks: attending === "yes" ? drinks : [], message, submittedAt: new Date().toISOString() });
  if (message) await addWish(name, message, "wish");
  return j({ ok: true });
};
